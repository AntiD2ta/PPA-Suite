#include <bits/stdc++.h>

using namespace std;

int main(){
    cout << "Simple .deb package\n";
}


